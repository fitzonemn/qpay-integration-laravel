@extends('layouts.app')

@section('title', 'Create Payment')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-white">
                <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Create New Payment</h4>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('payment.create') }}">
                    @csrf

                    <div class="mb-3">
                        <label for="amount" class="form-label">Amount (₮) *</label>
                        <div class="input-group">
                            <input type="number"
                                   class="form-control form-control-lg @error('amount') is-invalid @enderror"
                                   id="amount"
                                   name="amount"
                                   value="{{ old('amount', 111) }}"
                                   min="100"
                                   step="1"
                                   required
                                   placeholder="Enter amount">
                            <span class="input-group-text">₮</span>
                        </div>
                        @error('amount')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                        <small class="text-muted">Minimum: 100 ₮</small>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description *</label>
                        <input type="text"
                               class="form-control @error('description') is-invalid @enderror"
                               id="description"
                               name="description"
                               value="{{ old('description', 'our test') }}"
                               maxlength="255"
                               required
                               placeholder="Payment for...">
                        @error('description')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="receiver_code" class="form-label">Receiver Code</label>
                        <input type="text"
                               class="form-control @error('receiver_code') is-invalid @enderror"
                               id="receiver_code"
                               name="receiver_code"
                               value="{{ old('receiver_code', 'terminal') }}"
                               placeholder="Enter receiver code">
                        @error('receiver_code')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                        <small class="text-muted">Default: "terminal"</small>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-credit-card me-2"></i>Create Payment Invoice
                        </button>
                    </div>
                </form>

                <hr class="my-4">

                <div class="text-center">
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        You will be redirected to QPay payment page after creating the invoice.
                    </small>
                </div>
            </div>
        </div>

        <div class="mt-4 text-center">
            <a href="{{ route('payment.test') }}" class="btn btn-outline-info btn-sm" target="_blank">
                <i class="fas fa-plug me-1"></i>Test API Connection
            </a>
        </div>
    </div>
</div>
@endsection
