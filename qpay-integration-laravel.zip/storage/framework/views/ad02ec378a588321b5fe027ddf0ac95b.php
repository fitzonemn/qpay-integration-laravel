<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QPay Integration Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
        }
        .feature-icon {
            font-size: 3rem;
            color: #667eea;
            margin-bottom: 1rem;
        }
        .btn-start {
            padding: 12px 30px;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <section class="hero text-center">
        <div class="container">
            <i class="fas fa-credit-card fa-5x mb-4"></i>
            <h1 class="display-4 fw-bold mb-3">QPay Payment Integration</h1>
            <p class="lead mb-4">Easy QR code payments with Mongolia's leading payment gateway</p>
            <a href="<?php echo e(route('payment.index')); ?>" class="btn btn-light btn-lg btn-start">
                <i class="fas fa-play me-2"></i>Start Demo
            </a>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-4 mb-4">
                    <div class="feature-icon">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <h3>QR Code Payments</h3>
                    <p>Scan and pay easily with QPay app using QR codes</p>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Secure & Reliable</h3>
                    <p>Bank-level security with real-time payment processing</p>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-icon">
                        <i class="fas fa-code"></i>
                    </div>
                    <h3>Easy Integration</h3>
                    <p>Simple API integration for Laravel applications</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How it Works -->
    <section class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-5">How It Works</h2>
            <div class="row">
                <div class="col-md-3 text-center mb-4">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="fas fa-plus text-primary fa-2x"></i>
                    </div>
                    <h5>1. Create Invoice</h5>
                    <p>Enter payment amount and description</p>
                </div>
                <div class="col-md-3 text-center mb-4">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="fas fa-qrcode text-primary fa-2x"></i>
                    </div>
                    <h5>2. Scan QR Code</h5>
                    <p>Use QPay app to scan the QR code</p>
                </div>
                <div class="col-md-3 text-center mb-4">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="fas fa-check text-primary fa-2x"></i>
                    </div>
                    <h5>3. Confirm Payment</h5>
                    <p>Confirm the payment in QPay app</p>
                </div>
                <div class="col-md-3 text-center mb-4">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="fas fa-receipt text-primary fa-2x"></i>
                    </div>
                    <h5>4. Get Confirmation</h5>
                    <p>Receive instant payment confirmation</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="py-5 text-center">
        <div class="container">
            <h2 class="mb-4">Ready to Test?</h2>
            <p class="lead mb-4">Try our demo payment system with QPay sandbox environment</p>
            <a href="<?php echo e(route('payment.index')); ?>" class="btn btn-primary btn-lg">
                <i class="fas fa-credit-card me-2"></i>Start Payment Demo
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-2">QPay Integration Demo • Laravel <?php echo e(app()->version()); ?></p>
            <small class="text-muted">
                This is a demonstration project using QPay sandbox environment
            </small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\wamp64\www\qpay-integration\resources\views/welcome.blade.php ENDPATH**/ ?>