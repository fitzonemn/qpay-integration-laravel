<?php $__env->startSection('title', 'Payment Successful'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body text-center py-5">
                <div class="mb-4">
                    <i class="fas fa-check-circle fa-5x text-success"></i>
                </div>

                <h2 class="mb-3">Payment Successful!</h2>

                <div class="alert alert-success mb-4">
                    <i class="fas fa-check me-2"></i>
                    Your payment has been completed successfully.
                </div>

                <!-- Payment Summary -->
                <div class="card mb-4">
                    <div class="card-body text-start">
                        <h5 class="card-title"><i class="fas fa-receipt me-2"></i>Payment Summary</h5>
                        <table class="table table-sm">
                            <tr>
                                <th>Invoice No:</th>
                                <td><?php echo e($payment['invoice_no']); ?></td>
                            </tr>
                            <tr>
                                <th>Amount:</th>
                                <td class="fw-bold"><?php echo e(number_format($payment['amount'], 2)); ?> ₮</td>
                            </tr>
                            <tr>
                                <th>Description:</th>
                                <td><?php echo e($payment['description']); ?></td>
                            </tr>
                            <tr>
                                <th>Paid At:</th>
                                <td><?php echo e(date('Y-m-d H:i:s', $payment['paid_at'])); ?></td>
                            </tr>
                            <?php if(isset($payment['payment_id'])): ?>
                            <tr>
                                <th>Payment ID:</th>
                                <td><small><?php echo e($payment['payment_id']); ?></small></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('payment.index')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Create New Payment
                    </a>
                    <button onclick="window.print()" class="btn btn-outline-secondary">
                        <i class="fas fa-print me-2"></i>Print Receipt
                    </button>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <small class="text-muted">
                <i class="fas fa-info-circle me-1"></i>
                A confirmation has been sent to the callback URL.
            </small>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\qpay-integration-only\resources\views/payment/success.blade.php ENDPATH**/ ?>