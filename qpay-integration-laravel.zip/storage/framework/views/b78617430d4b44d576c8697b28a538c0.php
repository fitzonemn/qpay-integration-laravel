<?php $__env->startSection('title', 'Make Payment'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-white">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="fas fa-qrcode me-2"></i>Payment Invoice</h4>
                    <span class="payment-status status-<?php echo e($payment['status']); ?>">
                        <?php echo e(strtoupper($payment['status'])); ?>

                    </span>
                </div>
            </div>
            <div class="card-body">
                <!-- Payment Info -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5><i class="fas fa-receipt me-2"></i>Invoice Details</h5>
                        <table class="table table-sm">
                            <tr>
                                <th width="40%">Invoice No:</th>
                                <td><?php echo e($payment['invoice_no']); ?></td>
                            </tr>
                            <tr>
                                <th>Amount:</th>
                                <td class="fw-bold"><?php echo e(number_format($payment['amount'], 2)); ?> ₮</td>
                            </tr>
                            <tr>
                                <th>Description:</th>
                                <td><?php echo e($payment['description']); ?></td>
                            </tr>
                            <tr>
                                <th>Created:</th>
                                <td><?php echo e(date('Y-m-d H:i:s', $payment['created_at'])); ?></td>
                            </tr>
                        </table>
                    </div>

                    <div class="col-md-6">
                        <h5><i class="fas fa-mobile-alt me-2"></i>Payment Methods</h5>
                        <div class="list-group">
                            <?php if($payment['qr_image']): ?>
                            <div class="list-group-item">
                                <i class="fas fa-qrcode me-2 text-primary"></i>
                                Scan QR Code with QPay App
                            </div>
                            <?php endif; ?>

                            <?php if($payment['qpay_url']): ?>
                            <a href="<?php echo e($payment['qpay_url']); ?>" target="_blank" class="list-group-item list-group-item-action">
                                <i class="fas fa-external-link-alt me-2 text-success"></i>
                                Open in QPay App
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- QR Code Section -->
                <?php if($payment['qr_image'] || $payment['qr_text']): ?>
                <div class="text-center mb-4">
                    <h5><i class="fas fa-qrcode me-2"></i>Scan QR Code</h5>

                    <div class="qrcode-container d-inline-block p-4">
                        <?php if($payment['qr_image'] && str_starts_with($payment['qr_image'], 'data:image')): ?>
                            <!-- Display base64 image -->
                            <img src="<?php echo e($payment['qr_image']); ?>"
                                alt="QR Code"
                                class="img-fluid"
                                style="max-width: 250px; height: auto;">

                        <?php elseif($payment['qr_image'] && filter_var($payment['qr_image'], FILTER_VALIDATE_URL)): ?>
                            <!-- Display URL image -->
                            <img src="<?php echo e($payment['qr_image']); ?>"
                                alt="QR Code"
                                class="img-fluid"
                                style="max-width: 250px; height: auto;"
                                onerror="this.style.display='none'; document.getElementById('fallback-qr').style.display='block';">

                        <?php elseif($payment['qr_text']): ?>
                            <!-- Generate QR code from text -->
                            <div id="qrcode-canvas"></div>

                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                QR code image not available
                            </div>
                        <?php endif; ?>

                        <!-- Fallback QR generator -->
                        <div id="fallback-qr" style="display: none;">
                            <canvas id="fallback-qrcode"></canvas>
                        </div>
                    </div>

                    <?php if($payment['qr_text']): ?>
                    <div class="mt-3">
                        <small class="text-muted">
                            <i class="fas fa-info-circle me-1"></i>
                            QR Text: <code><?php echo e(Str::limit($payment['qr_text'], 50)); ?></code>
                        </small>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                    <?php if($payment['qpay_url']): ?>
                    <a href="<?php echo e($payment['qpay_url']); ?>" target="_blank" class="btn btn-success btn-lg me-md-2">
                        <i class="fas fa-external-link-alt me-2"></i>Pay with QPay
                    </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('payment.cancel')); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to cancel this payment?')">
                        <i class="fas fa-times me-2"></i>Cancel Payment
                    </a>
                </div>
            </div>

            <!-- Status Check Area -->
            <div class="card-footer bg-light">
                <div class="text-center">
                    <div id="status-message" class="mb-2"></div>
                    <button id="check-status" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-sync-alt me-1"></i>Check Payment Status
                    </button>
                    <div class="mt-2">
                        <small class="text-muted">
                            Status updates automatically every 10 seconds
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-3">
            <a href="<?php echo e(route('payment.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-plus me-1"></i>Create New Payment
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Generate QR Code
    <?php if($payment['qr_text']): ?>
    QRCode.toCanvas(document.getElementById('qrcode'), '<?php echo e($payment['qr_text']); ?>', {
        width: 200,
        margin: 2,
        color: {
            dark: '#000000',
            light: '#FFFFFF'
        }
    }, function (error) {
        if (error) console.error(error);
    });
    <?php endif; ?>

    // Check payment status
    function checkPaymentStatus() {
        fetch('<?php echo e(route("payment.check")); ?>')
            .then(response => response.json())
            .then(data => {
                const statusElement = document.querySelector('.payment-status');
                const statusMessage = document.getElementById('status-message');

                if (data.success) {
                    if (data.is_paid) {
                        // Update status display
                        statusElement.textContent = 'PAID';
                        statusElement.className = 'payment-status status-paid';
                        statusMessage.innerHTML = '<div class="alert alert-success mb-0">Payment completed successfully!</div>';

                        // Disable check button
                        document.getElementById('check-status').disabled = true;

                        // Redirect to success page after 3 seconds
                        setTimeout(() => {
                            window.location.href = '<?php echo e(route("payment.success")); ?>';
                        }, 3000);

                        // Stop checking
                        clearInterval(checkInterval);
                    } else {
                        statusMessage.innerHTML = '<div class="alert alert-warning mb-0">Waiting for payment...</div>';
                    }
                } else {
                    statusMessage.innerHTML = `<div class="alert alert-danger mb-0">${data.message}</div>`;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('status-message').innerHTML =
                    '<div class="alert alert-danger mb-0">Failed to check status</div>';
            });
    }

    // Manual check button
    document.getElementById('check-status').addEventListener('click', checkPaymentStatus);

    // Auto-check every 10 seconds
    let checkInterval = setInterval(checkPaymentStatus, 10000);

    // Initial check
    setTimeout(checkPaymentStatus, 1000);

    // Stop checking after 30 minutes
    setTimeout(() => {
        clearInterval(checkInterval);
        document.getElementById('status-message').innerHTML =
            '<div class="alert alert-info mb-0">Payment session expired</div>';
    }, 30 * 60 * 1000);
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/qrcode@latest/build/qrcode.min.js"></script>
<script>
    // Generate QR Code from text if no image
    <?php if($payment['qr_text'] && (empty($payment['qr_image']) || !str_starts_with($payment['qr_image'], 'data:image'))): ?>
    document.addEventListener('DOMContentLoaded', function() {
        const qrText = '<?php echo e($payment["qr_text"]); ?>';

        // Try to generate QR code
        try {
            QRCode.toCanvas(document.getElementById('qrcode-canvas'), qrText, {
                width: 200,
                margin: 2,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            }, function (error) {
                if (error) {
                    console.error('QR generation error:', error);
                    // Show error message
                    const container = document.querySelector('.qrcode-container');
                    if (container) {
                        container.innerHTML = `
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Could not generate QR code. Use the payment link below.
                            </div>
                        `;
                    }
                }
            });
        } catch (error) {
            console.error('QR Code error:', error);
        }
    });
    <?php endif; ?>

    // Fallback QR generator
    function generateFallbackQR(text) {
        try {
            QRCode.toCanvas(document.getElementById('fallback-qrcode'), text, {
                width: 200,
                margin: 2
            });
        } catch (error) {
            console.error('Fallback QR error:', error);
        }
    }

    // Generate fallback if image fails to load
    document.addEventListener('DOMContentLoaded', function() {
        const qrImage = document.querySelector('.qrcode-container img');
        if (qrImage && '<?php echo e($payment["qr_text"]); ?>') {
            qrImage.addEventListener('error', function() {
                generateFallbackQR('<?php echo e($payment["qr_text"]); ?>');
            });
        }
    });

    // ... rest of your existing JavaScript ...
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\qpay-integration\resources\views/payment/show.blade.php ENDPATH**/ ?>