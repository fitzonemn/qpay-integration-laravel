<?php $__env->startSection('title', 'Create Payment'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-white">
                <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Create New Payment</h4>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('payment.create')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="amount" class="form-label">Amount (₮) *</label>
                        <div class="input-group">
                            <input type="number"
                                   class="form-control form-control-lg <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="amount"
                                   name="amount"
                                   value="<?php echo e(old('amount')); ?>"
                                   min="100"
                                   step="1"
                                   required
                                   placeholder="Enter amount">
                            <span class="input-group-text">₮</span>
                        </div>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="text-muted">Minimum: 100 ₮</small>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description *</label>
                        <input type="text"
                               class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="description"
                               name="description"
                               value="<?php echo e(old('description')); ?>"
                               maxlength="255"
                               required
                               placeholder="Payment for...">
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4">
                        <label for="receiver_code" class="form-label">Receiver Code</label>
                        <input type="text"
                               class="form-control <?php $__errorArgs = ['receiver_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="receiver_code"
                               name="receiver_code"
                               value="<?php echo e(old('receiver_code', 'terminal')); ?>"
                               placeholder="Enter receiver code">
                        <?php $__errorArgs = ['receiver_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="text-muted">Default: "terminal"</small>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-credit-card me-2"></i>Create Payment Invoice
                        </button>
                    </div>
                </form>

                <hr class="my-4">

                <div class="text-center">
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        You will be redirected to QPay payment page after creating the invoice.
                    </small>
                </div>
            </div>
        </div>

        <div class="mt-4 text-center">
            <a href="<?php echo e(route('payment.test')); ?>" class="btn btn-outline-info btn-sm" target="_blank">
                <i class="fas fa-plug me-1"></i>Test API Connection
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\qpay-integration\resources\views/payment/form.blade.php ENDPATH**/ ?>