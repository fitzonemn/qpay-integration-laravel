<?php

return [
    'sandbox' => env('QPAY_SANDBOX', false),

    'credentials' => [
        'username' => env('QPAY_USERNAME', 'TEST_MERCHANT'),
        'password' => env('QPAY_PASSWORD', 'WBDUzy8n'),
        'invoice_code' => env('QPAY_INVOICE_CODE', 'TEST_INVOICE'),
    ],

    'urls' => [
        'sandbox' => [
            'base' => 'https://merchant-sandbox.qpay.mn/v2/',
            'auth' => 'https://merchant-sandbox.qpay.mn/v2/auth/token',
            'refresh' => 'https://merchant-sandbox.qpay.mn/v2/auth/refresh',
            'invoice' => 'https://merchant-sandbox.qpay.mn/v2/invoice',
            'payment' => 'https://merchant-sandbox.qpay.mn/v2/payment',
            'ebarimt' => 'https://merchant-sandbox.qpay.mn/v2/ebarimt/create',
        ],
        'production' => [
            'base' => 'https://merchant.qpay.mn/v2/',
            'auth' => 'https://merchant.qpay.mn/v2/auth/token',
            'refresh' => 'https://merchant.qpay.mn/v2/auth/refresh',
            'invoice' => 'https://merchant.qpay.mn/v2/invoice',
            'payment' => 'https://merchant.qpay.mn/v2/payment',
            'ebarimt' => 'https://merchant.qpay.mn/v2/ebarimt/create',
        ],
    ],

    'defaults' => [
        'sender_branch_code' => env('QPAY_BRANCH_CODE', 'BRANCH-1'),
        'sender_staff_code' => env('QPAY_STAFF_CODE', 'STAFF-1'),
        'enable_expiry' => 'false',
        'allow_partial' => false,
        'allow_exceed' => false,
    ],
];
