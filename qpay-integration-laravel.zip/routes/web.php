<?php

use App\Http\Controllers\PaymentController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Payment Routes
Route::prefix('payment')->name('payment.')->group(function () {
    Route::get('/', [PaymentController::class, 'index'])->name('index');

    Route::post('/create', [PaymentController::class, 'create'])->name('create');
    Route::get('/show', [PaymentController::class, 'show'])->name('show');
    Route::post('/callback', [PaymentController::class, 'callback'])->name('callback');
    Route::get('/check', [PaymentController::class, 'checkStatus'])->name('check');
    Route::get('/success', [PaymentController::class, 'success'])->name('success');
    Route::get('/cancel', [PaymentController::class, 'cancel'])->name('cancel');

    Route::get('/test', [PaymentController::class, 'test'])->name('test');
});

Route::get('/payment/debug-qr', [PaymentController::class, 'debugQr'])->name('payment.debug.qr');
